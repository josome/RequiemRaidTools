-- GuildLoot – UI_SpielerTab.lua
-- Spieler-Tab: Build + Refresh

local GL = GuildLoot
local UI = GL.UI

local TAB_SPIELER = UI.TAB_SPIELER
local ColorDiff   = UI._H.ColorDiff

-- ============================================================
-- File-local state & Konstanten
-- ============================================================

local playerRows      = {}
local expandedPlayers = {}   -- expandedPlayers[fullName] = true/nil

local PRIO_LABEL = { [1]="|cffffcc00BIS|r", [2]="|cff6699ffOS|r", [4]="|cff888888Tmog|r" }
local CAT_LABEL  = { weapons="Weapon", trinket="Trinket", setItems="Set", other="Other" }
local SUB_ROW_H  = 20
local SUB_INDENT = 22   -- Einrückung der Sub-Rows

-- Item-Name aus WoW-Hyperlink oder [Name]-Format extrahieren
local function ParseItemName(link)
    if not link then return "?" end
    local name = link:match("|h%[(.-)%]|h")
    if name then return name end
    name = link:match("^%[(.-)%]$")
    if name then return name end
    return link
end

-- Farbcode aus Item-Qualität (0–6), Fallback Epic-Lila
local function ItemQualityHex(quality)
    local r, g, b = GetItemQualityColor(quality or 4)
    if r then
        return string.format("|cff%02x%02x%02x", r * 255, g * 255, b * 255)
    end
    return "|cffA335EE"
end

-- ============================================================
-- Spieler-Panel bauen
-- ============================================================

function UI.BuildSpielerPanel(parent)
    local panel = CreateFrame("Frame", nil, parent)
    panel:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, 0)
    panel:SetPoint("BOTTOMRIGHT", parent, "BOTTOMRIGHT", 0, 0)
    panel:Hide()

    -- Header
    local headers = { "Raider", "Loot", "Set", "Weapon", "Trinket", "Other", "Set Bonus" }
    local colW    = { 140, 30, 40, 50, 50, 46, 60 }
    local xOff = 4 + 20   -- 20px Platz für Toggle-Button
    for i, h in ipairs(headers) do
        local lbl = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        lbl:SetPoint("TOPLEFT", panel, "TOPLEFT", xOff, -6)
        lbl:SetWidth(colW[i])
        lbl:SetText(h)
        lbl:SetTextColor(1, 0.8, 0)
        xOff = xOff + colW[i] + 4
    end

    -- Trennlinie
    local div = panel:CreateTexture(nil, "BACKGROUND")
    div:SetColorTexture(0.4, 0.4, 0.4, 1)
    div:SetHeight(1)
    div:SetPoint("TOPLEFT", panel, "TOPLEFT", 4, -22)
    div:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -4, -22)

    -- Scroll-Bereich
    local scroll = CreateFrame("ScrollFrame", "GuildLootSpielerScroll", panel, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", div, "BOTTOMLEFT", 0, -2)
    scroll:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -26, 4)
    local content = CreateFrame("Frame", nil, scroll)
    content:SetSize(600, 1)
    scroll:SetScrollChild(content)
    panel.content = content
    panel.scroll  = scroll
    panel.colW    = colW

    return panel
end

-- ============================================================
-- Sub-Rows für einen aufgeklappten Spieler bauen
-- ============================================================

local function BuildItemSubRows(content, fullName, rowW, yOff)
    local log = GuildLootDB.currentRaid and GuildLootDB.currentRaid.lootLog or {}
    local shortN = GL.ShortName(fullName)
    local count  = 0

    for _, entry in ipairs(log) do
        if GL.ShortName(entry.player) == shortN then
            count = count + 1
            local subRow = CreateFrame("Frame", nil, content)
            subRow:SetSize(rowW - SUB_INDENT, SUB_ROW_H)
            subRow:SetPoint("TOPLEFT", content, "TOPLEFT", SUB_INDENT, yOff)

            -- leichter Hintergrund für Sub-Rows
            local bg = subRow:CreateTexture(nil, "BACKGROUND")
            bg:SetAllPoints()
            bg:SetColorTexture(0.1, 0.1, 0.1, 0.4)

            local x = 4

            -- Schwierigkeitsgrad
            local diffLbl = subRow:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            diffLbl:SetPoint("TOPLEFT", subRow, "TOPLEFT", x, -3)
            diffLbl:SetWidth(26)
            diffLbl:SetText(ColorDiff(entry.difficulty))
            x = x + 26 + 4

            -- Kategorie
            local catLbl = subRow:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            catLbl:SetPoint("TOPLEFT", subRow, "TOPLEFT", x, -3)
            catLbl:SetWidth(48)
            catLbl:SetText("|cffaaaaaa" .. (CAT_LABEL[entry.category] or "?") .. "|r")
            x = x + 48 + 4

            -- Prio
            local prioLbl = subRow:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            prioLbl:SetPoint("TOPLEFT", subRow, "TOPLEFT", x, -3)
            prioLbl:SetWidth(46)
            prioLbl:SetText(entry.winnerPrio and ("|cffaaaaaa" .. entry.winnerPrio .. "|r " .. (PRIO_LABEL[entry.winnerPrio] or "?")) or "|cff888888—|r")
            x = x + 46 + 4

            -- Item-Name (klickbar mit Tooltip falls echter Link vorhanden)
            local safeLink   = (entry.link or ""):find("|H") and entry.link or nil
            local itemColor  = ItemQualityHex(entry.quality)
            local itemText   = itemColor .. ParseItemName(entry.link or entry.item) .. "|r"

            local itemAnchor = subRow:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            itemAnchor:SetPoint("TOPLEFT", subRow, "TOPLEFT", x, -3)
            itemAnchor:SetWidth(0)  -- nur als Anker, kein sichtbarer Text

            UI._H.MakeItemLinkBtn(subRow, itemAnchor, 0, safeLink, itemText)

            subRow:Show()
            table.insert(playerRows, subRow)
            yOff = yOff - SUB_ROW_H
        end
    end

    -- Platzhalter wenn keine Items
    if count == 0 then
        local emptyRow = CreateFrame("Frame", nil, content)
        emptyRow:SetSize(rowW - SUB_INDENT, SUB_ROW_H)
        emptyRow:SetPoint("TOPLEFT", content, "TOPLEFT", SUB_INDENT, yOff)
        local emptyLbl = emptyRow:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        emptyLbl:SetPoint("TOPLEFT", emptyRow, "TOPLEFT", 4, -3)
        emptyLbl:SetText("|cff666666Kein Loot in diesem Raid|r")
        emptyRow:Show()
        table.insert(playerRows, emptyRow)
        yOff = yOff - SUB_ROW_H
    end

    return yOff
end

-- ============================================================
-- Spieler-Tab Refresh
-- ============================================================

function UI.RefreshSpielerTab()
    if UI.activeTab ~= TAB_SPIELER then return end
    if not UI.spielerPanel or not UI.spielerPanel.content then return end

    local scroll = UI.spielerPanel.scroll
    local w = scroll and scroll:GetWidth() or 0
    if w > 10 then
        UI.spielerPanel.content:SetWidth(w)
    end

    for _, r in ipairs(playerRows) do r:Hide() end
    playerRows = {}

    local participants = GuildLootDB.currentRaid.participants
    local absent       = GuildLootDB.currentRaid.absent
    local players      = GuildLootDB.players
    local colW         = UI.spielerPanel.colW
    local content      = UI.spielerPanel.content

    local yOff     = 0
    local zebraIdx = 0   -- separater Zähler für Zebra (Sub-Rows sollen Parity nicht brechen)

    for _, fullName in ipairs(participants) do
        local data     = players[fullName] or {}
        local isAbsent = absent[fullName]
        local row      = CreateFrame("Frame", nil, content)
        local rowW     = math.max(content:GetWidth() - 30, 200)
        row:SetSize(rowW, 22)
        row:SetPoint("TOPLEFT", content, "TOPLEFT", 4, yOff)

        -- Zebra-Streifen (nur Player-Rows, nicht Sub-Rows)
        if (zebraIdx % 2 == 0) then
            local bg = row:CreateTexture(nil, "BACKGROUND")
            bg:SetAllPoints()
            bg:SetColorTexture(1, 1, 1, 0.03)
        end

        local xOff = 4

        -- Toggle-Button ▶/▼
        local isExpanded = expandedPlayers[fullName]
        local toggleBtn = CreateFrame("Button", nil, row)
        toggleBtn:SetSize(16, 16)
        toggleBtn:SetPoint("TOPLEFT", row, "TOPLEFT", xOff, -3)
        if isExpanded then
            toggleBtn:SetNormalTexture("Interface\\Buttons\\UI-MinusButton-UP")
            toggleBtn:SetPushedTexture("Interface\\Buttons\\UI-MinusButton-DOWN")
        else
            toggleBtn:SetNormalTexture("Interface\\Buttons\\UI-PlusButton-UP")
            toggleBtn:SetPushedTexture("Interface\\Buttons\\UI-PlusButton-DOWN")
        end
        toggleBtn:SetHighlightTexture("Interface\\Buttons\\UI-PlusButton-Hilight")
        toggleBtn:SetScript("OnClick", function()
            expandedPlayers[fullName] = not expandedPlayers[fullName]
            UI.RefreshSpielerTab()
        end)
        xOff = xOff + 16 + 4

        -- Spalte 1: Raider-Name
        local nameLbl = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        nameLbl:SetPoint("TOPLEFT", row, "TOPLEFT", xOff, -3)
        nameLbl:SetWidth(colW[1])
        local displayName = GL.ShortName(fullName)
        if isAbsent then
            nameLbl:SetText("|cff888888" .. displayName .. " (abw.)|r")
        else
            nameLbl:SetText(GL.ColoredName(displayName, data.class))
        end
        xOff = xOff + colW[1] + 4

        -- Spalte 2: Lootberechtigt (Checkbox)
        local check = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
        check:SetSize(18, 18)
        check:SetPoint("TOPLEFT", row, "TOPLEFT", xOff, -2)
        check:SetChecked(data.lootEligible ~= false)
        check:SetEnabled(GL.IsMasterLooter())
        check:SetScript("OnClick", function(self)
            GL.CreatePlayerRecord(fullName)
            GuildLootDB.players[fullName].lootEligible = self:GetChecked()
        end)
        xOff = xOff + colW[2] + 4

        -- Spalten 3-5: Set, Waffe, Trinket
        local diffCats = { { "setItems", colW[3] }, { "weapons", colW[4] }, { "trinket", colW[5] } }
        for _, dc in ipairs(diffCats) do
            local cat, cw = dc[1], dc[2]
            local ld = data.lastDifficulty and data.lastDifficulty[cat]
            local diffBtn = CreateFrame("Button", nil, row)
            diffBtn:SetSize(cw, 18)
            diffBtn:SetPoint("TOPLEFT", row, "TOPLEFT", xOff, -2)
            local diffLbl = diffBtn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            diffLbl:SetAllPoints()
            diffLbl:SetJustifyH("CENTER")
            diffLbl:SetText(ColorDiff(ld))
            diffBtn:SetScript("OnClick", function()
                UI.ShowDifficultyOverrideMenu(diffBtn, fullName, cat, diffLbl)
            end)
            xOff = xOff + cw + 4
        end

        -- Spalte 6: Other-Loot Anzahl (Dropdown 0-10)
        local otherBtn = CreateFrame("Button", nil, row)
        otherBtn:SetSize(colW[6], 18)
        otherBtn:SetPoint("TOPLEFT", row, "TOPLEFT", xOff, -2)
        local otherBtnLbl = otherBtn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        otherBtnLbl:SetAllPoints()
        otherBtnLbl:SetJustifyH("CENTER")
        local function UpdateOtherBtn()
            GL.CreatePlayerRecord(fullName)
            local p = GuildLootDB.players[fullName]
            p.counts = p.counts or {}
            otherBtnLbl:SetText(tostring(p.counts.other or 0))
        end
        UpdateOtherBtn()
        otherBtn:SetScript("OnClick", function()
            UI.ShowCountMenu(otherBtn, fullName, "other", 0, 10, otherBtnLbl)
        end)
        xOff = xOff + colW[6] + 4

        -- Spalte 7: Set Bonus (Dropdown 0-4)
        local setBtn = CreateFrame("Button", nil, row)
        setBtn:SetSize(colW[7], 18)
        setBtn:SetPoint("TOPLEFT", row, "TOPLEFT", xOff, -2)
        local setBtnLbl = setBtn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        setBtnLbl:SetAllPoints()
        setBtnLbl:SetJustifyH("CENTER")
        local function UpdateSetBtn()
            GL.CreatePlayerRecord(fullName)
            local sp = GuildLootDB.players[fullName].setPieces or 0
            if sp >= 4 then
                setBtnLbl:SetText("|cff00ff00" .. sp .. "/4|r")
            else
                setBtnLbl:SetText(sp .. "/4")
            end
        end
        UpdateSetBtn()
        setBtn:SetScript("OnClick", function()
            UI.ShowCountMenu(setBtn, fullName, "setPieces", 0, 4, setBtnLbl, UpdateSetBtn)
        end)

        row:Show()
        table.insert(playerRows, row)
        yOff     = yOff - 24
        zebraIdx = zebraIdx + 1

        -- Sub-Rows wenn aufgeklappt
        if isExpanded then
            yOff = BuildItemSubRows(content, fullName, rowW, yOff)
        end
    end
    content:SetHeight(math.max(1, -yOff))
end

-- Difficulty-Override Dropdown
function UI.ShowDifficultyOverrideMenu(anchor, fullName, category, label)
    local menu = CreateFrame("Frame", "GuildLootDiffMenu", UIParent, "UIDropDownMenuTemplate")
    local options = {
        { text = "Normal (N)",  diff = "N" },
        { text = "Heroic (H)",  diff = "H" },
        { text = "Mythic (M)",  diff = "M" },
        { text = "— (keine)",   diff = nil },
    }
    UIDropDownMenu_Initialize(menu, function(self, level)
        for _, opt in ipairs(options) do
            local info = UIDropDownMenu_CreateInfo()
            info.text     = opt.text
            info.notCheckable = true
            info.func     = function()
                GL.CreatePlayerRecord(fullName)
                GuildLootDB.players[fullName].lastDifficulty[category] = opt.diff
                label:SetText(ColorDiff(opt.diff))
                CloseDropDownMenus()
            end
            UIDropDownMenu_AddButton(info)
        end
    end, "MENU")
    ToggleDropDownMenu(1, nil, menu, anchor, 0, 0)
end

-- Zahlen-Dropdown für Other (0-10) und Set Bonus (0-4)
function UI.ShowCountMenu(anchor, fullName, field, minVal, maxVal, label, updateFn)
    local menu = CreateFrame("Frame", "GuildLootCountMenu", UIParent, "UIDropDownMenuTemplate")
    UIDropDownMenu_Initialize(menu, function()
        for v = minVal, maxVal do
            local info = UIDropDownMenu_CreateInfo()
            info.text = tostring(v)
            info.notCheckable = true
            info.func = function()
                GL.CreatePlayerRecord(fullName)
                local p = GuildLootDB.players[fullName]
                if field == "setPieces" then
                    p.setPieces = v
                else
                    p.counts = p.counts or {}
                    p.counts[field] = v
                end
                if updateFn then
                    updateFn()
                else
                    p.counts = p.counts or {}
                    label:SetText(tostring(p.counts[field] or 0))
                end
                CloseDropDownMenus()
            end
            UIDropDownMenu_AddButton(info)
        end
    end, "MENU")
    ToggleDropDownMenu(1, nil, menu, anchor, 0, 0)
end
